/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: category
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `category` (
  `category_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_type` enum('top', 'bottom') NOT NULL,
  `category_image` text NOT NULL,
  `is_active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`category_id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: chest_details
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `chest_details` (
  `chest_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `chest` varchar(255) NOT NULL,
  `mudho_golai` varchar(255) NOT NULL,
  `mudho` varchar(255) NOT NULL,
  `cross_bay` varchar(255) NOT NULL,
  `ba_mudho_down` varchar(255) NOT NULL,
  `so_down` varchar(255) NOT NULL,
  PRIMARY KEY (`chest_id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: customer
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `customer` (
  `customer_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_mobile` varchar(255) NOT NULL,
  `customer_address` text NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: customer_measurement
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `customer_measurement` (
  `cm_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `customer_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `category_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `measurement_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `measurement` varchar(255) NOT NULL,
  `measurement_2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cm_id`),
  KEY `customer_id` (`customer_id`),
  KEY `category_id` (`category_id`),
  KEY `measurement_id` (`measurement_id`),
  CONSTRAINT `customer_measurement_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `customer_measurement_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `customer_measurement_ibfk_3` FOREIGN KEY (`measurement_id`) REFERENCES `measurement` (`measurement_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: login
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `login` (
  `login_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `whatsapp_id` varchar(255) NOT NULL,
  `whatsapp_token` varchar(255) NOT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: measurement
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `measurement` (
  `measurement_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `category_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `measurement_name` varchar(255) NOT NULL,
  PRIMARY KEY (`measurement_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `measurement_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: order
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `order` (
  `order_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `customer_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `total` int NOT NULL,
  `payment` int DEFAULT '0',
  `order_date` datetime NOT NULL,
  `delivery_date` datetime NOT NULL,
  `shirt_pocket` int NOT NULL,
  `pant_pocket` int NOT NULL,
  `pant_pinch` int NOT NULL,
  `type` int DEFAULT '0',
  `bill_no` int DEFAULT '0',
  PRIMARY KEY (`order_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: order_images
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `order_images` (
  `order_image_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `order_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `image_name` text NOT NULL,
  PRIMARY KEY (`order_image_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `order_images_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: order_payments
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `order_payments` (
  `order_payment_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `order_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `amount` double NOT NULL,
  `payment_date` datetime NOT NULL,
  PRIMARY KEY (`order_payment_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `order_payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: order_product
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `order_product` (
  `order_product_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `order_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `category_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `worker_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `parent` int DEFAULT '0',
  `qty` int NOT NULL,
  `price` int DEFAULT '0',
  `status` enum('pending', 'assign', 'complete') NOT NULL DEFAULT 'pending',
  `work_price` int DEFAULT NULL,
  `work_total` int DEFAULT NULL,
  `assign_date` datetime DEFAULT NULL,
  PRIMARY KEY (`order_product_id`),
  KEY `order_id` (`order_id`),
  KEY `category_id` (`category_id`),
  KEY `worker_id` (`worker_id`),
  CONSTRAINT `order_product_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `order_product_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `order_product_ibfk_3` FOREIGN KEY (`worker_id`) REFERENCES `worker` (`worker_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: purchase
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `purchase` (
  `purchase_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `party_name` varchar(255) NOT NULL,
  `amount` int NOT NULL,
  `payment` float DEFAULT NULL,
  `outstand` float NOT NULL,
  `details` text,
  `challan` varchar(255) DEFAULT NULL,
  `purchase_date` datetime NOT NULL,
  PRIMARY KEY (`purchase_id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: purchase_payment
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `purchase_payment` (
  `Purchase_payment_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `purchase_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `amount` double NOT NULL,
  `payment_date` datetime NOT NULL,
  PRIMARY KEY (`Purchase_payment_id`),
  KEY `purchase_id` (`purchase_id`),
  CONSTRAINT `purchase_payment_ibfk_1` FOREIGN KEY (`purchase_id`) REFERENCES `purchase` (`purchase_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: worker
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `worker` (
  `worker_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `worker_name` varchar(255) NOT NULL,
  `worker_mobile` varchar(255) NOT NULL,
  `worker_address` text NOT NULL,
  `worker_photo` text NOT NULL,
  `worker_proof` text NOT NULL,
  PRIMARY KEY (`worker_id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: worker_payment
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `worker_payment` (
  `worker_payment_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `worker_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `amount` double NOT NULL,
  `payment_date` datetime NOT NULL,
  `type` int NOT NULL,
  PRIMARY KEY (`worker_payment_id`),
  KEY `worker_id` (`worker_id`),
  CONSTRAINT `worker_payment_ibfk_1` FOREIGN KEY (`worker_id`) REFERENCES `worker` (`worker_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: worker_price
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `worker_price` (
  `worker_price_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `worker_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `category_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `price` int NOT NULL,
  PRIMARY KEY (`worker_price_id`),
  KEY `worker_id` (`worker_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `worker_price_ibfk_1` FOREIGN KEY (`worker_id`) REFERENCES `worker` (`worker_id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `worker_price_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: category
# ------------------------------------------------------------

INSERT INTO
  `category` (
    `category_id`,
    `category_name`,
    `category_type`,
    `category_image`,
    `is_active`
  )
VALUES
  (
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    'weistcoat',
    'top',
    '/images/CategoryImage/1712292814.png',
    0
  );
INSERT INTO
  `category` (
    `category_id`,
    `category_name`,
    `category_type`,
    `category_image`,
    `is_active`
  )
VALUES
  (
    '092468c6-8067-4e37-a5e2-810488be2a53',
    'jodhpuri suit',
    'top',
    '/images/CategoryImage/1712239690.png',
    0
  );
INSERT INTO
  `category` (
    `category_id`,
    `category_name`,
    `category_type`,
    `category_image`,
    `is_active`
  )
VALUES
  (
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    'pant',
    'bottom',
    '/images/CategoryImage/1712237709.png',
    1
  );
INSERT INTO
  `category` (
    `category_id`,
    `category_name`,
    `category_type`,
    `category_image`,
    `is_active`
  )
VALUES
  (
    '8f0ad21f-3d9e-4988-8621-c3d7b49a04aa',
    'blezer',
    'top',
    '/images/CategoryImage/1712298139.png',
    1
  );
INSERT INTO
  `category` (
    `category_id`,
    `category_name`,
    `category_type`,
    `category_image`,
    `is_active`
  )
VALUES
  (
    'b9563341-c982-4ad5-a285-92f8083bfddc',
    'cargo',
    'bottom',
    '/images/CategoryImage/1712300093.jpg',
    0
  );
INSERT INTO
  `category` (
    `category_id`,
    `category_name`,
    `category_type`,
    `category_image`,
    `is_active`
  )
VALUES
  (
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'Shirts',
    'top',
    '/images/CategoryImage/1712238228.png',
    1
  );
INSERT INTO
  `category` (
    `category_id`,
    `category_name`,
    `category_type`,
    `category_image`,
    `is_active`
  )
VALUES
  (
    'ce5db8a0-a3ef-4538-9e34-d39c7517d368',
    'kurta',
    'top',
    '/images/CategoryImage/1712238735.png',
    1
  );
INSERT INTO
  `category` (
    `category_id`,
    `category_name`,
    `category_type`,
    `category_image`,
    `is_active`
  )
VALUES
  (
    'cff6d91b-f699-4960-b415-080221093423',
    'suit',
    'top',
    '/images/CategoryImage/1712233315.jpg',
    1
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: chest_details
# ------------------------------------------------------------

INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '022c66c1-056e-446a-8419-207b42a64e60',
    '35.25',
    '-1.25*9.5',
    '8.5',
    '10',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '033eba3c-5636-4d48-b92d-5b87461d27b8',
    '35.5',
    '-1.25*9.5',
    '8.5',
    '10',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '04bb6771-fd5b-4917-965e-129f962aa6da',
    '36.25',
    '-1.25*9.5',
    '8.75',
    '10',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '0653517f-af99-4a25-be0e-06d9239fccdd',
    '41.75',
    '-1.25*10.25',
    '9.75',
    '11',
    '4.75',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '083107ee-10cd-4627-bf5e-150f5792b0eb',
    '46',
    '-1.25*10.75',
    '9.75',
    '11.5',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '0891a790-ace3-4f38-9724-9b092945891b',
    '42.5',
    '-1.25*10.5',
    '9.75',
    '11.25',
    '4.75',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '0b6901ed-60cd-4ead-85ae-057dc136e02d',
    '39.75',
    '-1.25*10.25',
    '9.25',
    '10.75',
    '4.5',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '0fdb1668-aa74-4c45-9a8f-7f28e2a867ab',
    '43',
    '-1.25*10.5',
    '9.75',
    '11.25',
    '4.75',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '116619d0-f31d-4c6c-8e64-93a8e010f0e5',
    '40.5',
    '-1.25*10.25',
    '9.25',
    '10.75',
    '4.5',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '1e20c476-ed2f-482c-969a-aa0521754327',
    '39.25',
    '-1.25*10.25',
    '9',
    '10.75',
    '4.5',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '2809abe9-947c-4127-9efc-1b3aeb93b027',
    '38',
    '-1.25*10',
    '9',
    '10.5',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '2eca4bdf-1e06-4a18-807a-54ed500663eb',
    '31.25',
    '-1.25*9.25',
    '8.25',
    '9.5',
    '4',
    '1.75'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '344251bf-b787-4d1f-bccc-8d296e71bbbe',
    '42',
    '-1.25*10.25',
    '9.75',
    '11',
    '4.75',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '38715203-5442-42ec-bc5c-4f70d42306b2',
    '41',
    '-1.25*10.25',
    '9.25',
    '10.75',
    '4.75',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '38957f1b-d318-49ab-bc90-8978e99f9ee2',
    '31',
    '-1.25*9.25',
    '8.25',
    '9.5',
    '4',
    '1.75'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '395fdec6-2042-4db1-82c4-87139bf99aa9',
    '45.25',
    '-1.25*10.75',
    '9.75',
    '11.5',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '3e6187e1-e7be-4c88-92f2-7e2897e6b8ee',
    '36',
    '-1.25*9.5',
    '8.75',
    '10',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '4563565c-3cc8-4183-a46a-d1335f674afb',
    '41.5',
    '-1.25*10.25',
    '9.75',
    '11',
    '4.75',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '46d53e54-c778-4c91-9811-5599a5854c52',
    '32.75',
    '-1.25*9.5',
    '8.5',
    '9.75',
    '4',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '49dd6cfb-070e-4b9b-84fc-87afff260335',
    '45.75',
    '-1.25*10.75',
    '9.75',
    '11.5',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '4a47cdac-ae8a-44f6-8709-ad8f50644723',
    '46.25',
    '-1.25*11',
    '9.75',
    '11.5',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '4ed6075e-35e1-4e4f-aa4a-16e9c450a3f7',
    '37.75',
    '-1.25*10',
    '9',
    '10.5',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '4fd5866e-c106-45e1-861f-1f509647a426',
    '44.25',
    '-1.25*10.5',
    '9.75',
    '11.25',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '5601b00e-e5c3-4007-becb-edf889473901',
    '32',
    '-1.25*10.5',
    '8.5',
    '9.75',
    '4',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '57df75ad-8f69-4c48-bb52-5474d8b16a17',
    '40',
    '-1.25*10.25',
    '9.25',
    '10.75',
    '4.5',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '59342791-3dc5-421c-9edf-b40a3ddb96f5',
    '37',
    '-1.25*10',
    '8.75',
    '10.5',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '5b29b0e1-cf06-4c66-93b2-31636cc0dbb5',
    '31.75',
    '-1.25*9.25',
    '8.25',
    '9.5',
    '4',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '5ba73902-9641-41a0-b7b6-891fa4499d2c',
    '44',
    '-1.25*10.5',
    '9.75',
    '11.25',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '616c2a84-3b82-4b29-8230-dd6f06efa482',
    '34.75',
    '-1.25*9.5',
    '8.5',
    '10',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '66e8bbc0-626e-4c98-a67b-80952c703b43',
    '32.25',
    '-1.25*9.5',
    '8.5',
    '9.75',
    '4',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '686017ae-4ba9-4b1f-b495-e6cd1e5d27c9',
    '30.5',
    '-1.25*9.25',
    '8.25',
    '9.5',
    '4',
    '1.75'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '70c55824-cdd8-4399-adb8-492401f0e6b8',
    '46.5',
    '-1.25*11',
    '9.75',
    '11.5',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '79ecd44f-93cb-48bb-8dc0-2d1fbb052552',
    '45.5',
    '-1.25*10.75',
    '9.75',
    '11.5',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '7b7bbba8-1306-451f-8838-e5c658f89ed8',
    '47.75',
    '-1.25*11.5',
    '10.25',
    '11.75',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '7fb0ac76-b3a6-41a4-acea-c2e081159837',
    '34.25',
    '-1.25*9.5',
    '8.5',
    '10',
    '4',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '836f1012-b6ce-4f7d-97c6-ece7fb47b96f',
    '31.5',
    '-1.25*9.25',
    '8.25',
    '9.5',
    '4',
    '1.75'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '855dd76e-8e82-499f-81d7-4c0b79ed9e08',
    '47.25',
    '-1.25*11',
    '10',
    '11.75',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '89f6f245-4cbd-4230-9d31-c6390a1e72c4',
    '44.75',
    '-1.25*10.75',
    '9.75',
    '11.5',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '92c97b72-7abe-49d4-b0f0-d101984f0d99',
    '37.25',
    '-1.25*10',
    '8.75',
    '10.5',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '92c9d313-a1f5-441b-b625-28f066412cf2',
    '42.25',
    '-1.25*10.5',
    '9.75',
    '11.25',
    '4.75',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '9445bfd7-27ee-4748-a8b6-81232cdb0f58',
    '35.75',
    '-1.25*9.5',
    '8.5',
    '10',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    '9f6630cc-5013-4888-904d-fb27f8d2e3ea',
    '39',
    '-1.25*10.25',
    '9',
    '10.75',
    '4.5',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'a01baae9-33e3-4017-b238-189e4ee62f38',
    '40.75',
    '-1.25*10.25',
    '9.25',
    '10.75',
    '4.5',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'a0a96056-8caa-4a1d-986a-9fc9bc6d3a47',
    '33',
    '-1.25*9.5',
    '8.5',
    '9.75',
    '4',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'a0bd7044-1d49-4258-b1e3-297a802de238',
    '30',
    '-1.25*9.25',
    '8.25',
    '9.5',
    '4',
    '1.75'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'a238c1cd-0717-449d-9b85-105626458900',
    '43.25',
    '-1.25*10.5',
    '9.75',
    '11.25',
    '4.75',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'a9a7215d-7524-4f5d-b5ed-1c0e27a3c459',
    '37.5',
    '-1.25*10',
    '8.75',
    '10.5',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'adcd72f6-7dfe-4abd-925b-7af3045cd040',
    '34.5',
    '-1.25*9.5',
    '8.5',
    '10',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'af186afb-740f-4f08-9f50-b5f961e92d2c',
    '41.25',
    '-1.25*10.25',
    '9.25',
    '11',
    '4.75',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'af4d672f-8256-4823-9b32-b1831b84742c',
    '43.75',
    '-1.25*10.5',
    '9.75',
    '11.25',
    '4.75',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'afb82c18-c090-41df-bb4e-53c3dee5032f',
    '42.75',
    '-1.25*10.5',
    '9.75',
    '11.25',
    '4.75',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'b805bc89-f375-48d9-a253-69093c0a7449',
    '44.5',
    '-1.25*10.5',
    '9.75',
    '11.25',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'bb05a35a-717b-4cb6-a4d8-71146d7efe3d',
    '45',
    '-1.25*10.75',
    '9.75',
    '11.5',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'bb8ae5bb-3537-49b5-8e6d-cddf1ca68165',
    '47',
    '-1.25*11',
    '10',
    '11.75',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'bbdbbce5-89b5-4274-930c-f1ff81d0e97c',
    '43.5',
    '-1.25*10.5',
    '9.75',
    '11.25',
    '4.75',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'c7954947-1609-468c-9f6f-bde7abd14053',
    '39.5',
    '-1.25*10.25',
    '9',
    '10.75',
    '4.5',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'c8cbe18a-0435-4a15-a7db-dfaa7058bde4',
    '36.75',
    '-1.25*9.75',
    '8.75',
    '10.25',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'c9a02a62-f353-4385-b4f5-2f319a18b8df',
    '38.75',
    '-1.25*10.25',
    '9',
    '10.75',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'cfaba8dc-e1f5-4251-b7f2-e0c1e831329e',
    '40.25',
    '-1.25*10.25',
    '9.25',
    '10.75',
    '4.5',
    '2.25'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'd2eae44f-9179-441f-95ac-c76503668326',
    '32.5',
    '-1.25*9.5',
    '8.5',
    '9.75',
    '4',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'd4109201-786c-4ecf-a4e4-534ca4fec533',
    '30.75',
    '-1.25*9.25',
    '8.25',
    '9.5',
    '4',
    '1.75'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'd43c1bf3-0e95-4f55-ab3a-634c9189d3eb',
    '34',
    '-1.25*9.5',
    '8.5',
    '9.75',
    '4',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'd688adb6-7144-462e-b941-e714208960e1',
    '48',
    '-1.25*11.5',
    '10.25',
    '11.75',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'd7ce1707-09c5-46ef-995c-e712bcb56dcd',
    '33.5',
    '-1.25*9.5',
    '8.5',
    '9.75',
    '4',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'd8d0d87b-33f3-474d-96ee-4fbb2f8e63b0',
    '38.25',
    '-1.25*10',
    '9',
    '10.5',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'e1ca2571-4354-4ee3-9b9f-98b7bfb46afc',
    '33.25',
    '-1.25*9.5',
    '8.5',
    '9.75',
    '4',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'e4224f68-22fc-4192-8b1a-c99e62ed5920',
    '35',
    '-1.25*9.5',
    '8.5',
    '10',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'e429f7b1-ef7b-471c-9d28-e13bb5f4085a',
    '46.75',
    '-1.25*11',
    '10',
    '11.75',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'e5943590-42e8-4567-8b9e-193f1e28378f',
    '33.75',
    '-1.25*9.5',
    '8.5',
    '9.75',
    '4',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'e9dcd151-42e8-40ab-a478-f644ee2807ab',
    '47.5',
    '-1.25*11.5',
    '10.25',
    '11.75',
    '5',
    '2.5'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'ea267db5-67b9-4698-b010-610d12d22478',
    '30.25',
    '-1.25*9.25',
    '8.25',
    '9.5',
    '4',
    '1.75'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'f79e8081-da39-41f8-be31-091f4107cfb5',
    '38.5',
    '-1.25*10.25',
    '9',
    '10.75',
    '4.25',
    '2'
  );
INSERT INTO
  `chest_details` (
    `chest_id`,
    `chest`,
    `mudho_golai`,
    `mudho`,
    `cross_bay`,
    `ba_mudho_down`,
    `so_down`
  )
VALUES
  (
    'f848bf30-750a-4f56-8aa5-922d44b8bfda',
    '36.5',
    '-1.25*9.75',
    '8.75',
    '10.25',
    '4.25',
    '2'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: customer
# ------------------------------------------------------------

INSERT INTO
  `customer` (
    `customer_id`,
    `customer_name`,
    `customer_mobile`,
    `customer_address`
  )
VALUES
  (
    '0b97afbb-cd00-4b58-947f-c82634a1f05c',
    'vaishnavi',
    '8529637410',
    'surat'
  );
INSERT INTO
  `customer` (
    `customer_id`,
    `customer_name`,
    `customer_mobile`,
    `customer_address`
  )
VALUES
  (
    '25d9b4b1-4941-4f41-963b-1ab7541261c5',
    'Yasir Sandoval',
    '1985963565',
    'Repellendus Quo nes'
  );
INSERT INTO
  `customer` (
    `customer_id`,
    `customer_name`,
    `customer_mobile`,
    `customer_address`
  )
VALUES
  (
    '2a7a19b6-3f6c-4003-9319-7924ceea16a4',
    'Karan',
    '9865327410',
    'surat'
  );
INSERT INTO
  `customer` (
    `customer_id`,
    `customer_name`,
    `customer_mobile`,
    `customer_address`
  )
VALUES
  (
    '49d2d3b8-de1e-4d0d-abfd-f77fff8186a1',
    'nirali',
    '9313304886',
    'surat'
  );
INSERT INTO
  `customer` (
    `customer_id`,
    `customer_name`,
    `customer_mobile`,
    `customer_address`
  )
VALUES
  (
    '86d973db-7d54-4207-a609-12a349af9c5f',
    'Hermione Burns',
    '8820202020',
    'Qui possimus omnis '
  );
INSERT INTO
  `customer` (
    `customer_id`,
    `customer_name`,
    `customer_mobile`,
    `customer_address`
  )
VALUES
  (
    'a87847c9-871f-4ba9-bcf8-995904f85820',
    'Lester Sherman',
    '97',
    'Nam maiores in fugia'
  );
INSERT INTO
  `customer` (
    `customer_id`,
    `customer_name`,
    `customer_mobile`,
    `customer_address`
  )
VALUES
  (
    'cf410a38-40e3-4c91-9299-5f5993ad9e55',
    'shruti',
    '7985461320',
    'surat'
  );
INSERT INTO
  `customer` (
    `customer_id`,
    `customer_name`,
    `customer_mobile`,
    `customer_address`
  )
VALUES
  (
    'ead8061e-4caf-457b-b82c-d98cfdcbffa3',
    'brijesh',
    '1234567899',
    'surat'
  );
INSERT INTO
  `customer` (
    `customer_id`,
    `customer_name`,
    `customer_mobile`,
    `customer_address`
  )
VALUES
  (
    'efd3f1d5-39ec-488b-8e9e-ae6c409e52fa',
    'smit',
    '7891594310',
    'amreli'
  );
INSERT INTO
  `customer` (
    `customer_id`,
    `customer_name`,
    `customer_mobile`,
    `customer_address`
  )
VALUES
  (
    'fa0bc134-62b9-461b-9ea2-1b121c26f978',
    'shruti',
    '9876543100',
    'surat'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: customer_measurement
# ------------------------------------------------------------

INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '0041421e-3539-4018-a760-6e557f99062e',
    '25d9b4b1-4941-4f41-963b-1ab7541261c5',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '2cb2d4d2-a0e2-4bd0-8761-158d82117c49',
    '23',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '0735c2cd-84a6-4012-bbf1-99e9dade7607',
    '0b97afbb-cd00-4b58-947f-c82634a1f05c',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '2cb2d4d2-a0e2-4bd0-8761-158d82117c49',
    '2',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '0b4ee03c-b4cd-4493-803e-3087b5c0f068',
    'cf410a38-40e3-4c91-9299-5f5993ad9e55',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '2cb2d4d2-a0e2-4bd0-8761-158d82117c49',
    '10',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '13073f2b-88a1-45ce-965e-508dde68c3fb',
    'efd3f1d5-39ec-488b-8e9e-ae6c409e52fa',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'e4f090b0-5de9-4b27-919e-d9764ee2cc17',
    '35.5',
    '10'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '1676d34e-2240-4daf-b9f9-398bd61495a9',
    'ead8061e-4caf-457b-b82c-d98cfdcbffa3',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'e4f090b0-5de9-4b27-919e-d9764ee2cc17',
    '35.25',
    '2'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '2a00439a-90a2-442b-9d34-bd6ab990c308',
    '25d9b4b1-4941-4f41-963b-1ab7541261c5',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    '0040a08a-6364-4738-834f-b85c0275d4d8',
    '12',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '323ade75-beaa-4101-ae4f-c4066cc59cbe',
    'cf410a38-40e3-4c91-9299-5f5993ad9e55',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '42140838-0ced-4f7e-b08d-7ed450a2bf63',
    '25',
    '25'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '32773461-c40a-48aa-8b40-dc1a2b6a3f36',
    '49d2d3b8-de1e-4d0d-abfd-f77fff8186a1',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'e4f090b0-5de9-4b27-919e-d9764ee2cc17',
    '46',
    '15'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '35f03d4d-be89-4f75-a39c-0a9fcd1eacfc',
    'fa0bc134-62b9-461b-9ea2-1b121c26f978',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    '82f15513-f3b4-47fa-84be-b685619105c2',
    '2',
    '3'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '3a937e19-331f-4441-8cd5-fcbecf2ad237',
    'fa0bc134-62b9-461b-9ea2-1b121c26f978',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'cf2cbb82-6cff-4afa-86c0-3b57e1319031',
    '3',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '4245db97-bad4-4d92-a3ef-384ec785901f',
    '2a7a19b6-3f6c-4003-9319-7924ceea16a4',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'e4f090b0-5de9-4b27-919e-d9764ee2cc17',
    '35.25',
    '2'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '5b1466dc-c5c5-4600-9acb-4e529499687d',
    '0b97afbb-cd00-4b58-947f-c82634a1f05c',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    '5e7bb166-ea9e-46dc-8161-0621490d306e',
    '2',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '5d5993af-2bdc-4b67-b7a7-67872a395f7e',
    'ead8061e-4caf-457b-b82c-d98cfdcbffa3',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    '5e7bb166-ea9e-46dc-8161-0621490d306e',
    '2',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '6d12395c-c145-4638-87da-0dea99179a1e',
    '0b97afbb-cd00-4b58-947f-c82634a1f05c',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '42140838-0ced-4f7e-b08d-7ed450a2bf63',
    '2',
    '2'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '7029630d-b7a3-4e79-b155-90ef4920f812',
    '2a7a19b6-3f6c-4003-9319-7924ceea16a4',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '42140838-0ced-4f7e-b08d-7ed450a2bf63',
    '2',
    '4'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '73930fe7-8240-4070-b39a-1fdb71088f6d',
    'ead8061e-4caf-457b-b82c-d98cfdcbffa3',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'cf2cbb82-6cff-4afa-86c0-3b57e1319031',
    '20',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '7540563b-47f6-48f5-ba6d-9c1b29b3a2ae',
    'a87847c9-871f-4ba9-bcf8-995904f85820',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    '82f15513-f3b4-47fa-84be-b685619105c2',
    '79',
    '46'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '79f18e1a-84ae-4c93-878a-b611701555b5',
    '25d9b4b1-4941-4f41-963b-1ab7541261c5',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '42140838-0ced-4f7e-b08d-7ed450a2bf63',
    '46',
    '40'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '7e1eb136-c9d0-4d10-a12f-1e2f395beb15',
    '49d2d3b8-de1e-4d0d-abfd-f77fff8186a1',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    '82f15513-f3b4-47fa-84be-b685619105c2',
    '10',
    '10'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '82cbc5ad-2f20-412b-bc73-db3fdd805f09',
    'a87847c9-871f-4ba9-bcf8-995904f85820',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    '0040a08a-6364-4738-834f-b85c0275d4d8',
    '47',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '871fed4f-7af8-4e1b-bffe-85b6f8f20f19',
    '2a7a19b6-3f6c-4003-9319-7924ceea16a4',
    'ce5db8a0-a3ef-4538-9e34-d39c7517d368',
    'ede2a0a1-d400-41e8-ac50-7a1f6f1088a7',
    '2',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '89221c4d-c131-45ec-98fc-3c76c18d44ad',
    '2a7a19b6-3f6c-4003-9319-7924ceea16a4',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '2cb2d4d2-a0e2-4bd0-8761-158d82117c49',
    '8',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '8d3f76ff-85d2-45c7-a71f-023943716e65',
    'fa0bc134-62b9-461b-9ea2-1b121c26f978',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'e4f090b0-5de9-4b27-919e-d9764ee2cc17',
    '46',
    '2'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '8eab0b12-0fbf-4fad-8d58-e6111d41fffa',
    'fa0bc134-62b9-461b-9ea2-1b121c26f978',
    'b9563341-c982-4ad5-a285-92f8083bfddc',
    'b31ee65e-fdf5-45f2-8f11-81247b6d396e',
    '4',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '91e04706-1aa5-434d-9913-79c8fa4f9585',
    '49d2d3b8-de1e-4d0d-abfd-f77fff8186a1',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '2cb2d4d2-a0e2-4bd0-8761-158d82117c49',
    '20',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '93da3a4c-7177-45e2-8bfe-303ed1652018',
    '49d2d3b8-de1e-4d0d-abfd-f77fff8186a1',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    '5e7bb166-ea9e-46dc-8161-0621490d306e',
    '15',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    '9fc797fc-cd6f-4093-a948-812b42ab7747',
    '0b97afbb-cd00-4b58-947f-c82634a1f05c',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'e4f090b0-5de9-4b27-919e-d9764ee2cc17',
    '36.25',
    '2'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'a09828f9-166e-4572-9ff8-0806645c8725',
    '25d9b4b1-4941-4f41-963b-1ab7541261c5',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    '82f15513-f3b4-47fa-84be-b685619105c2',
    '87',
    '53'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'a0bc3ad5-e065-40e2-82c8-17bab4184321',
    '2a7a19b6-3f6c-4003-9319-7924ceea16a4',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    '5e7bb166-ea9e-46dc-8161-0621490d306e',
    '2',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'a2535c35-0fb7-4909-bb94-fc4e1049dc4d',
    'efd3f1d5-39ec-488b-8e9e-ae6c409e52fa',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    '5e7bb166-ea9e-46dc-8161-0621490d306e',
    '1',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'a4a1fe98-60f2-40fe-91cd-7ed00c8bad66',
    '49d2d3b8-de1e-4d0d-abfd-f77fff8186a1',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    '0040a08a-6364-4738-834f-b85c0275d4d8',
    '10',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'a9b91cca-4125-43b3-8d18-e7267fe16827',
    'cf410a38-40e3-4c91-9299-5f5993ad9e55',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'e4f090b0-5de9-4b27-919e-d9764ee2cc17',
    '35.25',
    '2'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'af3e2ef9-eb5d-4cd9-8822-71418c2ba71f',
    '86d973db-7d54-4207-a609-12a349af9c5f',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    '82f15513-f3b4-47fa-84be-b685619105c2',
    '22',
    '7'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'b2b26d69-0a04-4832-8325-9844f902b45c',
    '49d2d3b8-de1e-4d0d-abfd-f77fff8186a1',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'cf2cbb82-6cff-4afa-86c0-3b57e1319031',
    '15',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'b492fe51-38f9-4179-80cb-004aee3d2e47',
    'fa0bc134-62b9-461b-9ea2-1b121c26f978',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '2cb2d4d2-a0e2-4bd0-8761-158d82117c49',
    '4',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'b8286bdc-183c-4552-9840-441125940dd2',
    'cf410a38-40e3-4c91-9299-5f5993ad9e55',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'cf2cbb82-6cff-4afa-86c0-3b57e1319031',
    '4',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'bdf5d6c1-38fd-4fd6-971e-3c8a641ac12d',
    'fa0bc134-62b9-461b-9ea2-1b121c26f978',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    '0040a08a-6364-4738-834f-b85c0275d4d8',
    '2',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'c379c3ab-e76c-44d6-88af-d877a81d1bb1',
    'cf410a38-40e3-4c91-9299-5f5993ad9e55',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    '5e7bb166-ea9e-46dc-8161-0621490d306e',
    '4',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'c644f4e1-99b0-45c6-bf4e-e5e5a43add0e',
    'a87847c9-871f-4ba9-bcf8-995904f85820',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '2cb2d4d2-a0e2-4bd0-8761-158d82117c49',
    '11',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'c64cb784-af76-4a89-a196-fbb2f0cf7b19',
    '86d973db-7d54-4207-a609-12a349af9c5f',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '42140838-0ced-4f7e-b08d-7ed450a2bf63',
    '92',
    '37'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'c6dc0a8d-dbfe-45da-b61b-ffd03deb4f64',
    'fa0bc134-62b9-461b-9ea2-1b121c26f978',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    '5e7bb166-ea9e-46dc-8161-0621490d306e',
    '4',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'c9457665-d1c2-485f-bc93-c72ed9478725',
    '0b97afbb-cd00-4b58-947f-c82634a1f05c',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'cf2cbb82-6cff-4afa-86c0-3b57e1319031',
    '12',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'd28cb97f-8b57-4962-9a54-7785a53ea308',
    'fa0bc134-62b9-461b-9ea2-1b121c26f978',
    'b9563341-c982-4ad5-a285-92f8083bfddc',
    'e45cfd2d-186b-45af-bf83-1efc9e91db72',
    '4',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'd527b5b9-8cf3-44fd-9caa-ca2aa1040979',
    '49d2d3b8-de1e-4d0d-abfd-f77fff8186a1',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '42140838-0ced-4f7e-b08d-7ed450a2bf63',
    '20',
    '20'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'f525fef3-0fca-4d26-a92c-f30d4ee73b05',
    'cf410a38-40e3-4c91-9299-5f5993ad9e55',
    'ce5db8a0-a3ef-4538-9e34-d39c7517d368',
    'ede2a0a1-d400-41e8-ac50-7a1f6f1088a7',
    '4',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'f5feb32f-fe02-4afd-ad25-75fc05a0b4df',
    'a87847c9-871f-4ba9-bcf8-995904f85820',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '42140838-0ced-4f7e-b08d-7ed450a2bf63',
    '68',
    '98'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'f75e67a5-be3a-40b1-9212-1eca1892a66b',
    '86d973db-7d54-4207-a609-12a349af9c5f',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    '0040a08a-6364-4738-834f-b85c0275d4d8',
    '96',
    NULL
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'fa637017-cdb2-4d75-a2fb-24e3f67378ed',
    'fa0bc134-62b9-461b-9ea2-1b121c26f978',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '42140838-0ced-4f7e-b08d-7ed450a2bf63',
    '4',
    '4'
  );
INSERT INTO
  `customer_measurement` (
    `cm_id`,
    `customer_id`,
    `category_id`,
    `measurement_id`,
    `measurement`,
    `measurement_2`
  )
VALUES
  (
    'fb044dd3-3030-40f3-9823-c05a64574801',
    '86d973db-7d54-4207-a609-12a349af9c5f',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    '2cb2d4d2-a0e2-4bd0-8761-158d82117c49',
    '53',
    NULL
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: login
# ------------------------------------------------------------

INSERT INTO
  `login` (
    `login_id`,
    `user_name`,
    `password`,
    `whatsapp_id`,
    `whatsapp_token`
  )
VALUES
  (
    '38e59bc0-f3f3-431a-83d8-f936c30bcdb0',
    'parth',
    'parth123',
    '658E5FE2B7A1E',
    '652932ef0e526'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: measurement
# ------------------------------------------------------------

INSERT INTO
  `measurement` (
    `measurement_id`,
    `category_id`,
    `measurement_name`
  )
VALUES
  (
    '0040a08a-6364-4738-834f-b85c0275d4d8',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    'R'
  );
INSERT INTO
  `measurement` (
    `measurement_id`,
    `category_id`,
    `measurement_name`
  )
VALUES
  (
    '2cb2d4d2-a0e2-4bd0-8761-158d82117c49',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    'W'
  );
INSERT INTO
  `measurement` (
    `measurement_id`,
    `category_id`,
    `measurement_name`
  )
VALUES
  (
    '2d8d5581-cdce-486b-9090-0ff7ba90c2fe',
    'cff6d91b-f699-4960-b415-080221093423',
    'L'
  );
INSERT INTO
  `measurement` (
    `measurement_id`,
    `category_id`,
    `measurement_name`
  )
VALUES
  (
    '42140838-0ced-4f7e-b08d-7ed450a2bf63',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    'L'
  );
INSERT INTO
  `measurement` (
    `measurement_id`,
    `category_id`,
    `measurement_name`
  )
VALUES
  (
    '5e7bb166-ea9e-46dc-8161-0621490d306e',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'L'
  );
INSERT INTO
  `measurement` (
    `measurement_id`,
    `category_id`,
    `measurement_name`
  )
VALUES
  (
    '6c1c10c1-03ef-4748-8c7c-781c2798b4c7',
    '8f0ad21f-3d9e-4988-8621-c3d7b49a04aa',
    'L'
  );
INSERT INTO
  `measurement` (
    `measurement_id`,
    `category_id`,
    `measurement_name`
  )
VALUES
  (
    '6fea5038-139c-4cd9-abd2-d89a0092cce0',
    '8f0ad21f-3d9e-4988-8621-c3d7b49a04aa',
    'S'
  );
INSERT INTO
  `measurement` (
    `measurement_id`,
    `category_id`,
    `measurement_name`
  )
VALUES
  (
    '82f15513-f3b4-47fa-84be-b685619105c2',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    'S'
  );
INSERT INTO
  `measurement` (
    `measurement_id`,
    `category_id`,
    `measurement_name`
  )
VALUES
  (
    '8d294121-6a0a-4ef2-b328-e0bd7b84f1ed',
    '092468c6-8067-4e37-a5e2-810488be2a53',
    'S'
  );
INSERT INTO
  `measurement` (
    `measurement_id`,
    `category_id`,
    `measurement_name`
  )
VALUES
  (
    'b31ee65e-fdf5-45f2-8f11-81247b6d396e',
    'b9563341-c982-4ad5-a285-92f8083bfddc',
    'M'
  );
INSERT INTO
  `measurement` (
    `measurement_id`,
    `category_id`,
    `measurement_name`
  )
VALUES
  (
    'cf2cbb82-6cff-4afa-86c0-3b57e1319031',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'CO'
  );
INSERT INTO
  `measurement` (
    `measurement_id`,
    `category_id`,
    `measurement_name`
  )
VALUES
  (
    'e45cfd2d-186b-45af-bf83-1efc9e91db72',
    'b9563341-c982-4ad5-a285-92f8083bfddc',
    'XL'
  );
INSERT INTO
  `measurement` (
    `measurement_id`,
    `category_id`,
    `measurement_name`
  )
VALUES
  (
    'e4f090b0-5de9-4b27-919e-d9764ee2cc17',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    'CH'
  );
INSERT INTO
  `measurement` (
    `measurement_id`,
    `category_id`,
    `measurement_name`
  )
VALUES
  (
    'ede2a0a1-d400-41e8-ac50-7a1f6f1088a7',
    'ce5db8a0-a3ef-4538-9e34-d39c7517d368',
    'L'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: order
# ------------------------------------------------------------

INSERT INTO
  `order` (
    `order_id`,
    `customer_id`,
    `total`,
    `payment`,
    `order_date`,
    `delivery_date`,
    `shirt_pocket`,
    `pant_pocket`,
    `pant_pinch`,
    `type`,
    `bill_no`
  )
VALUES
  (
    '2e31b6a4-ba7a-4e20-a012-630822124aa5',
    'ead8061e-4caf-457b-b82c-d98cfdcbffa3',
    800,
    800,
    '2024-04-04 05:30:00',
    '2024-04-27 05:30:00',
    0,
    0,
    1,
    0,
    2
  );
INSERT INTO
  `order` (
    `order_id`,
    `customer_id`,
    `total`,
    `payment`,
    `order_date`,
    `delivery_date`,
    `shirt_pocket`,
    `pant_pocket`,
    `pant_pinch`,
    `type`,
    `bill_no`
  )
VALUES
  (
    '3ddbd342-b167-41da-a0f7-cc0618ccbfc8',
    'a87847c9-871f-4ba9-bcf8-995904f85820',
    1712505,
    0,
    '2020-07-12 05:30:00',
    '2020-08-17 05:30:00',
    0,
    0,
    0,
    0,
    4
  );
INSERT INTO
  `order` (
    `order_id`,
    `customer_id`,
    `total`,
    `payment`,
    `order_date`,
    `delivery_date`,
    `shirt_pocket`,
    `pant_pocket`,
    `pant_pinch`,
    `type`,
    `bill_no`
  )
VALUES
  (
    '417d1b07-6707-41c4-bf60-88bc9aa05536',
    '49d2d3b8-de1e-4d0d-abfd-f77fff8186a1',
    434,
    0,
    '2024-04-05 05:30:00',
    '2024-04-06 05:30:00',
    0,
    0,
    0,
    0,
    8
  );
INSERT INTO
  `order` (
    `order_id`,
    `customer_id`,
    `total`,
    `payment`,
    `order_date`,
    `delivery_date`,
    `shirt_pocket`,
    `pant_pocket`,
    `pant_pinch`,
    `type`,
    `bill_no`
  )
VALUES
  (
    '633709d3-3097-4b26-8980-ba750593104d',
    'cf410a38-40e3-4c91-9299-5f5993ad9e55',
    5000,
    0,
    '2024-04-05 05:30:00',
    '2024-04-27 05:30:00',
    0,
    0,
    0,
    0,
    9
  );
INSERT INTO
  `order` (
    `order_id`,
    `customer_id`,
    `total`,
    `payment`,
    `order_date`,
    `delivery_date`,
    `shirt_pocket`,
    `pant_pocket`,
    `pant_pinch`,
    `type`,
    `bill_no`
  )
VALUES
  (
    '82d845f2-b829-4040-8e1d-67bddff2f993',
    '0b97afbb-cd00-4b58-947f-c82634a1f05c',
    2300,
    0,
    '2024-04-05 05:30:00',
    '2024-04-21 05:30:00',
    0,
    0,
    0,
    0,
    7
  );
INSERT INTO
  `order` (
    `order_id`,
    `customer_id`,
    `total`,
    `payment`,
    `order_date`,
    `delivery_date`,
    `shirt_pocket`,
    `pant_pocket`,
    `pant_pinch`,
    `type`,
    `bill_no`
  )
VALUES
  (
    'ec3143f7-acaf-40a6-b20a-e945436e32ce',
    'efd3f1d5-39ec-488b-8e9e-ae6c409e52fa',
    250,
    250,
    '2024-04-05 05:30:00',
    '2024-04-10 05:30:00',
    1,
    4,
    2,
    0,
    3
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: order_images
# ------------------------------------------------------------

INSERT INTO
  `order_images` (`order_image_id`, `order_id`, `image_name`)
VALUES
  (
    '37e51694-6a9f-46b7-8fff-d0abf9604630',
    '2e31b6a4-ba7a-4e20-a012-630822124aa5',
    ''
  );
INSERT INTO
  `order_images` (`order_image_id`, `order_id`, `image_name`)
VALUES
  (
    '43268678-594d-4846-9066-038e662215e1',
    '3ddbd342-b167-41da-a0f7-cc0618ccbfc8',
    ''
  );
INSERT INTO
  `order_images` (`order_image_id`, `order_id`, `image_name`)
VALUES
  (
    '70682c96-a9fb-4280-9fb3-6302057e3981',
    '417d1b07-6707-41c4-bf60-88bc9aa05536',
    ''
  );
INSERT INTO
  `order_images` (`order_image_id`, `order_id`, `image_name`)
VALUES
  (
    '7551b6b4-d438-4bde-8244-039e317e98bc',
    '633709d3-3097-4b26-8980-ba750593104d',
    ''
  );
INSERT INTO
  `order_images` (`order_image_id`, `order_id`, `image_name`)
VALUES
  (
    '80cc6055-ade3-466a-8664-35d8f6d53a64',
    'ec3143f7-acaf-40a6-b20a-e945436e32ce',
    '/images/OrderImage/1712298676.jpg'
  );
INSERT INTO
  `order_images` (`order_image_id`, `order_id`, `image_name`)
VALUES
  (
    'c3ec3d7c-2bd1-4396-812d-770a41d9de2e',
    '82d845f2-b829-4040-8e1d-67bddff2f993',
    ''
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: order_payments
# ------------------------------------------------------------

INSERT INTO
  `order_payments` (
    `order_payment_id`,
    `order_id`,
    `amount`,
    `payment_date`
  )
VALUES
  (
    '33893af8-4733-48d2-81eb-72d9a8cb4ee6',
    'ec3143f7-acaf-40a6-b20a-e945436e32ce',
    250,
    '2024-04-05 05:30:00'
  );
INSERT INTO
  `order_payments` (
    `order_payment_id`,
    `order_id`,
    `amount`,
    `payment_date`
  )
VALUES
  (
    '717c5e10-f2de-426e-936d-cbf7f0efcbc3',
    '2e31b6a4-ba7a-4e20-a012-630822124aa5',
    800,
    '2024-04-05 05:30:00'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: order_product
# ------------------------------------------------------------

INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    '07032f4f-7545-4258-82e8-487ea6334e94',
    'ec3143f7-acaf-40a6-b20a-e945436e32ce',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    NULL,
    0,
    1,
    250,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    '0f9205cd-0dfe-4a73-a15c-1fef575284dc',
    '3ddbd342-b167-41da-a0f7-cc0618ccbfc8',
    'ce5db8a0-a3ef-4538-9e34-d39c7517d368',
    NULL,
    0,
    377,
    469,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    '1f4f4254-7153-414b-aee8-58ea3ad1332b',
    '633709d3-3097-4b26-8980-ba750593104d',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    NULL,
    0,
    4,
    500,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    '3c305c1f-d6c3-4f16-9728-7dab1953864a',
    '3ddbd342-b167-41da-a0f7-cc0618ccbfc8',
    'ce5db8a0-a3ef-4538-9e34-d39c7517d368',
    NULL,
    0,
    377,
    367,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    '45669b18-4894-45fb-9d88-292c957053a2',
    '633709d3-3097-4b26-8980-ba750593104d',
    'ce5db8a0-a3ef-4538-9e34-d39c7517d368',
    NULL,
    0,
    3,
    500,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    '5fe26c54-0449-40c7-936c-97d4d2edc5a2',
    '82d845f2-b829-4040-8e1d-67bddff2f993',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    NULL,
    0,
    2,
    400,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    '629b6d74-dc23-43ac-9121-375eed7ccdff',
    '3ddbd342-b167-41da-a0f7-cc0618ccbfc8',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    NULL,
    0,
    281,
    469,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    '6be169d7-2cb9-4073-b2fa-18922b3e930f',
    '417d1b07-6707-41c4-bf60-88bc9aa05536',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    NULL,
    0,
    11,
    11,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    '70487921-0b4e-411f-85af-2b672e0bbabb',
    '82d845f2-b829-4040-8e1d-67bddff2f993',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    NULL,
    0,
    3,
    500,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    '74e062e0-795c-48b7-916e-731a97c5627e',
    '3ddbd342-b167-41da-a0f7-cc0618ccbfc8',
    'cff6d91b-f699-4960-b415-080221093423',
    NULL,
    0,
    74,
    126,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    '77e48e2f-cbf2-48db-aafc-31a2e844f81a',
    '3ddbd342-b167-41da-a0f7-cc0618ccbfc8',
    '8f0ad21f-3d9e-4988-8621-c3d7b49a04aa',
    NULL,
    0,
    320,
    974,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    '7f81cdb7-87a1-4c76-9110-5f79c53f6e94',
    '3ddbd342-b167-41da-a0f7-cc0618ccbfc8',
    '8f0ad21f-3d9e-4988-8621-c3d7b49a04aa',
    NULL,
    0,
    322,
    276,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    '89c83a8b-bcf4-4ee6-bce2-7ef4ef42edc9',
    '3ddbd342-b167-41da-a0f7-cc0618ccbfc8',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    NULL,
    0,
    769,
    974,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    '99851744-cb97-47fe-bfab-7d3672666e5d',
    '417d1b07-6707-41c4-bf60-88bc9aa05536',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    NULL,
    0,
    12,
    12,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    'a0d60346-c853-4e19-8b39-cd142c2c2774',
    '633709d3-3097-4b26-8980-ba750593104d',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    NULL,
    0,
    3,
    500,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    'a300d709-afe6-47f5-b4b1-3552b6121c2a',
    '3ddbd342-b167-41da-a0f7-cc0618ccbfc8',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    NULL,
    0,
    281,
    276,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    'b14d283a-2806-4910-ad02-bf1e21e6aad2',
    '2e31b6a4-ba7a-4e20-a012-630822124aa5',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    NULL,
    0,
    2,
    400,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    'bb41b408-2dda-48b7-8585-ed9c2c17b998',
    '3ddbd342-b167-41da-a0f7-cc0618ccbfc8',
    '8f0ad21f-3d9e-4988-8621-c3d7b49a04aa',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    0,
    1,
    974,
    'complete',
    1500,
    1500,
    '2024-04-05 05:30:00'
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    'c520b3c2-5028-4c57-8282-93545cb14214',
    '417d1b07-6707-41c4-bf60-88bc9aa05536',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    NULL,
    0,
    12,
    13,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    'da376003-43de-4eb6-a968-04d74c239a3e',
    '3ddbd342-b167-41da-a0f7-cc0618ccbfc8',
    'cff6d91b-f699-4960-b415-080221093423',
    NULL,
    0,
    74,
    367,
    'pending',
    NULL,
    NULL,
    NULL
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    'f623d54a-feff-463e-bb11-384d9d74969e',
    '417d1b07-6707-41c4-bf60-88bc9aa05536',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    0,
    1,
    13,
    'complete',
    300,
    300,
    '2024-04-05 05:30:00'
  );
INSERT INTO
  `order_product` (
    `order_product_id`,
    `order_id`,
    `category_id`,
    `worker_id`,
    `parent`,
    `qty`,
    `price`,
    `status`,
    `work_price`,
    `work_total`,
    `assign_date`
  )
VALUES
  (
    'f69c1e36-079e-4035-8a13-91d133c207be',
    '3ddbd342-b167-41da-a0f7-cc0618ccbfc8',
    '8f0ad21f-3d9e-4988-8621-c3d7b49a04aa',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    0,
    1,
    974,
    'assign',
    1500,
    1500,
    '2024-04-05 05:30:00'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: purchase
# ------------------------------------------------------------

INSERT INTO
  `purchase` (
    `purchase_id`,
    `party_name`,
    `amount`,
    `payment`,
    `outstand`,
    `details`,
    `challan`,
    `purchase_date`
  )
VALUES
  (
    '0ff4ee0c-7d57-4686-b23c-b5093829909b',
    'regular',
    15000,
    2000,
    13000,
    'bhavangar',
    '₹',
    '2024-04-05 10:03:07'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: purchase_payment
# ------------------------------------------------------------

INSERT INTO
  `purchase_payment` (
    `Purchase_payment_id`,
    `purchase_id`,
    `amount`,
    `payment_date`
  )
VALUES
  (
    '4f293507-71f2-4108-ab77-b4c52eb91f44',
    '0ff4ee0c-7d57-4686-b23c-b5093829909b',
    2000,
    '2024-04-05 05:30:00'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: worker
# ------------------------------------------------------------

INSERT INTO
  `worker` (
    `worker_id`,
    `worker_name`,
    `worker_mobile`,
    `worker_address`,
    `worker_photo`,
    `worker_proof`
  )
VALUES
  (
    '9620970c-14b6-41b0-a60b-b5c64076f744',
    'karan',
    '7412589510',
    'surat',
    '/images/WorkerProfile/1712231598.jpg',
    '/images/WorkerProof/1712236281.jpg'
  );
INSERT INTO
  `worker` (
    `worker_id`,
    `worker_name`,
    `worker_mobile`,
    `worker_address`,
    `worker_photo`,
    `worker_proof`
  )
VALUES
  (
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    'henil',
    '1478529630',
    'surat',
    '/images/WorkerProfile/1712296156.jpg',
    '/images/WorkerProof/1712292345.jpg'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: worker_payment
# ------------------------------------------------------------

INSERT INTO
  `worker_payment` (
    `worker_payment_id`,
    `worker_id`,
    `amount`,
    `payment_date`,
    `type`
  )
VALUES
  (
    '01a86bf1-d204-4dc2-9930-2247af78a53a',
    '9620970c-14b6-41b0-a60b-b5c64076f744',
    20000,
    '2024-04-05 05:30:00',
    0
  );
INSERT INTO
  `worker_payment` (
    `worker_payment_id`,
    `worker_id`,
    `amount`,
    `payment_date`,
    `type`
  )
VALUES
  (
    '08a4ab4b-a18b-4c5b-9247-1cccc88e3c49',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    300,
    '2024-04-05 05:30:00',
    0
  );
INSERT INTO
  `worker_payment` (
    `worker_payment_id`,
    `worker_id`,
    `amount`,
    `payment_date`,
    `type`
  )
VALUES
  (
    '0ca5b085-47cb-413e-a36c-33db6cacf6c2',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    1500,
    '2024-04-05 05:30:00',
    0
  );
INSERT INTO
  `worker_payment` (
    `worker_payment_id`,
    `worker_id`,
    `amount`,
    `payment_date`,
    `type`
  )
VALUES
  (
    '24dbb831-0af1-45d3-b8d3-d22f1aee6f86',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    201,
    '2024-04-05 05:30:00',
    0
  );
INSERT INTO
  `worker_payment` (
    `worker_payment_id`,
    `worker_id`,
    `amount`,
    `payment_date`,
    `type`
  )
VALUES
  (
    '3a47c17a-fbbd-4f3d-a55d-fce50136bebc',
    '9620970c-14b6-41b0-a60b-b5c64076f744',
    5000,
    '2024-04-05 05:30:00',
    0
  );
INSERT INTO
  `worker_payment` (
    `worker_payment_id`,
    `worker_id`,
    `amount`,
    `payment_date`,
    `type`
  )
VALUES
  (
    'a727598a-9abf-4de7-a49e-c23249c4fba2',
    '9620970c-14b6-41b0-a60b-b5c64076f744',
    200,
    '2024-04-05 05:30:00',
    0
  );
INSERT INTO
  `worker_payment` (
    `worker_payment_id`,
    `worker_id`,
    `amount`,
    `payment_date`,
    `type`
  )
VALUES
  (
    'b458d48a-202b-4d25-9881-18db6f2a18c0',
    '9620970c-14b6-41b0-a60b-b5c64076f744',
    200,
    '2024-04-04 05:30:00',
    0
  );
INSERT INTO
  `worker_payment` (
    `worker_payment_id`,
    `worker_id`,
    `amount`,
    `payment_date`,
    `type`
  )
VALUES
  (
    'c34a97f6-f23d-4629-b3e9-4ceffdd5ef90',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    1500,
    '2024-04-05 05:30:00',
    0
  );
INSERT INTO
  `worker_payment` (
    `worker_payment_id`,
    `worker_id`,
    `amount`,
    `payment_date`,
    `type`
  )
VALUES
  (
    'dcb280d7-50e7-469a-b7bd-b0498f53bd99',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    250,
    '2024-04-05 05:30:00',
    0
  );
INSERT INTO
  `worker_payment` (
    `worker_payment_id`,
    `worker_id`,
    `amount`,
    `payment_date`,
    `type`
  )
VALUES
  (
    'de6d3bd9-2461-4508-a9e7-03bdddb45248',
    '9620970c-14b6-41b0-a60b-b5c64076f744',
    1000,
    '2024-04-04 05:30:00',
    0
  );
INSERT INTO
  `worker_payment` (
    `worker_payment_id`,
    `worker_id`,
    `amount`,
    `payment_date`,
    `type`
  )
VALUES
  (
    'f5d66b09-b141-45ec-a479-172769e85eda',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    600,
    '2024-04-05 10:00:26',
    1
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: worker_price
# ------------------------------------------------------------

INSERT INTO
  `worker_price` (
    `worker_price_id`,
    `worker_id`,
    `category_id`,
    `price`
  )
VALUES
  (
    '06d76766-c18c-41ad-be29-586cb511a159',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    'ce5db8a0-a3ef-4538-9e34-d39c7517d368',
    300
  );
INSERT INTO
  `worker_price` (
    `worker_price_id`,
    `worker_id`,
    `category_id`,
    `price`
  )
VALUES
  (
    '1670261f-32e5-48c2-a08f-31ab56de13a1',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    'cff6d91b-f699-4960-b415-080221093423',
    1200
  );
INSERT INTO
  `worker_price` (
    `worker_price_id`,
    `worker_id`,
    `category_id`,
    `price`
  )
VALUES
  (
    '1999d4d2-f153-4e7c-9168-f8240829cb23',
    '9620970c-14b6-41b0-a60b-b5c64076f744',
    'ce5db8a0-a3ef-4538-9e34-d39c7517d368',
    500
  );
INSERT INTO
  `worker_price` (
    `worker_price_id`,
    `worker_id`,
    `category_id`,
    `price`
  )
VALUES
  (
    '47966e89-b414-4ac4-9d58-17885a1b2b4f',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    'b9563341-c982-4ad5-a285-92f8083bfddc',
    300
  );
INSERT INTO
  `worker_price` (
    `worker_price_id`,
    `worker_id`,
    `category_id`,
    `price`
  )
VALUES
  (
    '49554333-9820-465d-93df-bdb58432404c',
    '9620970c-14b6-41b0-a60b-b5c64076f744',
    'cff6d91b-f699-4960-b415-080221093423',
    100
  );
INSERT INTO
  `worker_price` (
    `worker_price_id`,
    `worker_id`,
    `category_id`,
    `price`
  )
VALUES
  (
    '4da40fc5-6e0a-4584-96f7-0f78bbf1948f',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    '092468c6-8067-4e37-a5e2-810488be2a53',
    500
  );
INSERT INTO
  `worker_price` (
    `worker_price_id`,
    `worker_id`,
    `category_id`,
    `price`
  )
VALUES
  (
    '53818967-6da6-47be-918c-01b816290b33',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    '8f0ad21f-3d9e-4988-8621-c3d7b49a04aa',
    1500
  );
INSERT INTO
  `worker_price` (
    `worker_price_id`,
    `worker_id`,
    `category_id`,
    `price`
  )
VALUES
  (
    '5b0fd5c2-c9e5-4e67-9ea0-4cc1143bf5b3',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    '051b70c4-2d63-4f9d-8e19-951f89ac1c58',
    300
  );
INSERT INTO
  `worker_price` (
    `worker_price_id`,
    `worker_id`,
    `category_id`,
    `price`
  )
VALUES
  (
    '944ddeae-14bc-4670-b129-8201fbeb496a',
    '9620970c-14b6-41b0-a60b-b5c64076f744',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    500
  );
INSERT INTO
  `worker_price` (
    `worker_price_id`,
    `worker_id`,
    `category_id`,
    `price`
  )
VALUES
  (
    '9594a4a2-584f-40ea-afba-b4b16a1e482e',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    '4de70153-4e11-4fb7-969c-d0d131a4ae21',
    201
  );
INSERT INTO
  `worker_price` (
    `worker_price_id`,
    `worker_id`,
    `category_id`,
    `price`
  )
VALUES
  (
    'ae68c203-1cd5-42b3-93cb-79025b192ee3',
    '9620970c-14b6-41b0-a60b-b5c64076f744',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    100
  );
INSERT INTO
  `worker_price` (
    `worker_price_id`,
    `worker_id`,
    `category_id`,
    `price`
  )
VALUES
  (
    'c0afbe69-afd4-4e8c-8ccc-ca65f195e363',
    '9620970c-14b6-41b0-a60b-b5c64076f744',
    '092468c6-8067-4e37-a5e2-810488be2a53',
    200
  );
INSERT INTO
  `worker_price` (
    `worker_price_id`,
    `worker_id`,
    `category_id`,
    `price`
  )
VALUES
  (
    'f946b34d-6b14-48bc-bf35-265c01a8c1ed',
    'fe103c88-f6ae-4f7e-a5fb-e4a223b48a18',
    'bb3405b5-c852-474f-bda4-22045bcc6389',
    250
  );

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
